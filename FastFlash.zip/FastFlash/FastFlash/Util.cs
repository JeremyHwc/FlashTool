﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FastFlash
{
    static class Util
    {
        public static String MONITOR_DIR_PATH = "";
        public static String ReadFile(String fileName)
        {
            StringBuilder str = new StringBuilder();
            using (FileStream fs = File.OpenRead(fileName))
            {
                long left = fs.Length;
                int maxLength = 100;//每次读取的最大长度  
                int start = 0;//起始位置  
                int num = 0;//已读取长度  
                while (left > 0)
                {
                    byte[] buffer = new byte[maxLength];//缓存读取结果  
                    char[] cbuffer = new char[maxLength];
                    fs.Position = start;//读取开始的位置  
                    num = 0;
                    if (left < maxLength)
                    {
                        num = fs.Read(buffer, 0, Convert.ToInt32(left));
                    }
                    else
                    {
                        num = fs.Read(buffer, 0, maxLength);
                    }
                    if (num == 0)
                    {
                        break;
                    }
                    start += num;
                    left -= num;
                    str = str.Append(Encoding.UTF8.GetString(buffer));
                }
            }
            return str.ToString();
        }

        public static void writeFile(String filePath, String content)
        {
            if(!File.Exists(filePath)){
                File.Create(filePath);
            }
            using (StreamWriter sw = new StreamWriter(filePath))
            {
                sw.Write(content);
            }

        }

        public static void runCmd(String workingDir, String batFilePath, String parammeters)
        {
            try
            {
                Process process = new Process();
                process.StartInfo.FileName = batFilePath; //设置要启动的应用程序，如：fastboot
                process.StartInfo.Arguments = parammeters; // 设置应用程序参数，如： flash boot0 "A_Debug/boot0.img"

                process.StartInfo.UseShellExecute = false;
                process.StartInfo.RedirectStandardInput = true;
                process.StartInfo.RedirectStandardOutput = true;
                process.StartInfo.RedirectStandardError = true;
                //process.StartInfo.CreateNoWindow = true;
                process.EnableRaisingEvents = true;  // 获取或设置在进程终止时是否应激发 Exited 事件；不论是正常退出还是异常退出。
                process.StartInfo.WorkingDirectory = workingDir; // **重点**，工作目录，必须是 bat 批处理文件所在的目录
                //process.OutputDataReceived += (object sender, DataReceivedEventArgs e) => Redirected(output, sender, e);
                //process.ErrorDataReceived += (object sender, DataReceivedEventArgs e) => Redirected(error, sender, e);
                process.Start();
                //process.BeginOutputReadLine();  // 开启异步读取输出操作
                //process.BeginErrorReadLine();  // 开启异步读取错误操作
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occurred :{0},{1}", ex.Message, ex.StackTrace.ToString());
            }
        }

        public static void runCmd1(String workingDir, String batFilePath, String parammeters)
        {
            Process proc = null;
            try
            {
                proc = new Process();
                proc.StartInfo.WorkingDirectory = workingDir;
                proc.StartInfo.FileName = batFilePath;
                proc.StartInfo.Arguments = parammeters;//this is argument
                proc.StartInfo.CreateNoWindow = false;
                proc.Start();
                proc.WaitForExit();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception Occurred :{0},{1}", ex.Message, ex.StackTrace.ToString());
            }
        }

    }
}
