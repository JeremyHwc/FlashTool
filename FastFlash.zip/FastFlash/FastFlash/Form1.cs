﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FastFlash
{
    public partial class Form1 : Form
    {
        private String LocalConfigDirPath = "C:\\Fastflash\\";
        private String LocalConfigFileName = "C:\\Fastflash\\config.txt";
        private String ConfigFileName = "config.txt";
        public static String BAT_FILE_NAME = "fastflash.bat";
        


        public Form1()
        {
            InitializeComponent();
            InitLocalFlashRecordFile();
            LoadLocalConfigFile();
        }

        private void LoadLocalConfigFile()
        {
            textAddress.Text = Util.ReadFile(LocalConfigFileName);
            textAddress.Focus();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            btConfirm.Enabled = false;
            btConfirm.Text = "请在编译服务器上运行python脚本，进行刷机操作";
            textAddress.Enabled = false;

            String path = textAddress.Text;
            Util.MONITOR_DIR_PATH = path;
            Util.writeFile(LocalConfigFileName, path);
            CreateConfigFile(path);
            CreateBatFile(path);
            FileListener.WatcherStart(path , ConfigFileName, true, true);
        }

        private void CreateBatFile(string dirPath)
        {
            if (!Directory.Exists(dirPath))
            {
                Directory.CreateDirectory(dirPath);
            }
            if (!dirPath.EndsWith("\\"))
            {
                dirPath += "\\";
            }
            if (!File.Exists(dirPath + BAT_FILE_NAME))
            {
                File.Create(dirPath + BAT_FILE_NAME);
                FileInfo info = new FileInfo(dirPath + ConfigFileName);
                if (info.Exists)
                {
                    info.Attributes = FileAttributes.Hidden;
                }
            }

            System.Reflection.Assembly Asmb = System.Reflection.Assembly.GetExecutingAssembly();
            string strName = Asmb.GetName().Name + ".Resources.fastflash.bat";
            System.IO.Stream ManifestStream = Asmb.GetManifestResourceStream(strName);
            if (ManifestStream != null)
            {
                byte[] StreamData = new byte[ManifestStream.Length];
                ManifestStream.Read(StreamData, 0, (int)ManifestStream.Length);
                string result = Encoding.UTF8.GetString(StreamData);

                Util.writeFile(dirPath + BAT_FILE_NAME, result);
            }
        }

        private void CreateConfigFile(String dirPath)
        {
            if (!Directory.Exists(dirPath))
            {
                Directory.CreateDirectory(dirPath);
            }
            if(!dirPath.EndsWith("\\"))
            {
                dirPath += "\\";
            }
            if (!File.Exists(dirPath + ConfigFileName)) {
                File.Create(dirPath + ConfigFileName);
                FileInfo info = new FileInfo(dirPath + ConfigFileName);
                if (info.Exists)
                {
                    info.Attributes = FileAttributes.Hidden;
                }
            }
        }

        private void InitLocalFlashRecordFile()
        {
            if (!Directory.Exists(LocalConfigDirPath))
            {
                Directory.CreateDirectory(LocalConfigDirPath);
            }
            if (!File.Exists(LocalConfigFileName))
            {
                File.Create(LocalConfigFileName);
            }
        }

        private void textAddress_TextChanged(object sender, EventArgs e)
        {

        }
    }


}
