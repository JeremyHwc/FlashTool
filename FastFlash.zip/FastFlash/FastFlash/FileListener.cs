﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FastFlash
{
    public partial class FileListener
    {
        static FileSystemWatcher watcher = new FileSystemWatcher();
        static int num = 0;
        static char[] SEPERATORS = { '#' };
        private static String LastContent;
        static System.Threading.Timer Mytimer = new System.Threading.Timer(new TimerCallback(TimerUp), null, Timeout.Infinite, 5000);  
        public static void WatcherStart(string StrWarcherPath, string FilterType, bool IsEnableRaising, bool IsInclude)
        {
            //初始化监听
            watcher.BeginInit();
            //设置监听文件类型
            watcher.Filter = FilterType;
            //设置是否监听子目录
            watcher.IncludeSubdirectories = IsInclude;
            //设置是否启用监听?
            watcher.EnableRaisingEvents = IsEnableRaising;
            //设置需要监听的更改类型(如:文件或者文件夹的属性,文件或者文件夹的创建时间;NotifyFilters枚举的内容)
            //watcher.NotifyFilter = NotifyFilters.Attributes | NotifyFilters.CreationTime | NotifyFilters.DirectoryName | NotifyFilters.FileName | NotifyFilters.LastAccess | NotifyFilters.LastWrite | NotifyFilters.Security | NotifyFilters.Size;
            watcher.NotifyFilter = NotifyFilters.LastWrite;
            //设置监听的路径
            watcher.Path = StrWarcherPath;
            //注册创建文件或目录时的监听事件
            //watcher.Created += new FileSystemEventHandler(watch_created);
            //注册当指定目录的文件或者目录发生改变的时候的监听事件
            watcher.Changed += new FileSystemEventHandler(watch_changed);
            //注册当删除目录的文件或者目录的时候的监听事件
            //watcher.Deleted += new FileSystemEventHandler(watch_deleted);
            //当指定目录的文件或者目录发生重命名的时候的监听事件
            //watcher.Renamed += new RenamedEventHandler(watch_renamed);
            //结束初始化
            watcher.EndInit();
        }

        private static void watch_changed(object sender, FileSystemEventArgs e)
        {
            try {
                //事件内容
                //事件内容
                //output("change:" + e.FullPath);
                String FileFullPath = e.FullPath;
                String content = Util.ReadFile(FileFullPath);

                bool isEmpty = (content == String.Empty);
                if (!isEmpty)
                {
                    string[] parameters = content.Split(SEPERATORS);
                    //MessageBox.Show(content);
                    Util.runCmd1(Util.MONITOR_DIR_PATH, Util.MONITOR_DIR_PATH + "\\" + Form1.BAT_FILE_NAME, parameters[0] + " " + parameters[1]);
                }
            }catch(Exception ex){
                MessageBox.Show(ex.Message);
            }
            
        }

        private static void TimerUp(object state)
        {
            Mytimer.Change(0, 1000); 
        }  
    }

    public class WatcherTimer
    {
        private int TimeoutMillis = 2000;

        System.IO.FileSystemWatcher fsw = new System.IO.FileSystemWatcher();
        System.Threading.Timer m_timer = null;
        List<String> files = new List<string>();
        FileSystemEventHandler fswHandler = null;

        public WatcherTimer(FileSystemEventHandler watchHandler)
        {
            m_timer = new System.Threading.Timer(new TimerCallback(OnTimer),
                         null, Timeout.Infinite, Timeout.Infinite);
            fswHandler = watchHandler;
        }

        public WatcherTimer(FileSystemEventHandler watchHandler, int timerInterval)
        {
            m_timer = new System.Threading.Timer(new TimerCallback(OnTimer),
                        null, Timeout.Infinite, Timeout.Infinite);
            TimeoutMillis = timerInterval;
            fswHandler = watchHandler;
        }

        public void OnFileChanged(object sender, FileSystemEventArgs e)
        {
            Mutex mutex = new Mutex(false, "FSW");
            mutex.WaitOne();
            if (!files.Contains(e.Name))
            {
                files.Add(e.Name);
            }
            mutex.ReleaseMutex();
            m_timer.Change(TimeoutMillis, Timeout.Infinite);
        }

        private void OnTimer(object state)
        {
            Mutex mutex = new Mutex(false, "FSW");
            mutex.WaitOne();
            
            mutex.ReleaseMutex();
            //fswHandler(this, new FileSystemEventArgs(WatcherChangeTypes.Changed, string.Empty, file));
        }
    }
}
